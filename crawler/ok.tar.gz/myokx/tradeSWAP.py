from crawler.myokx.open import TradeOpen
from crawler.myokx.close import TradeClose


class TradeSWAP(TradeOpen, TradeClose):
    pass
